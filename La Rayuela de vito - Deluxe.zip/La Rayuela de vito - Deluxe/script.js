let canvas = document.getElementById('canvas');
let ctx = canvas.getContext('2d');

let player = {x: 50, y: 350, size: 40, color: 'red', image: new Image()};
player.image.src = 'images/vito.png';

let enemies = [];
let squares = [];
let score = 0;
let level = 1;
let maxLevel = 3;
let music = new Audio();
music.loop = true;
let volume = 0.5;

function startGame() {
    document.getElementById('menu').style.display = 'none';
    document.getElementById('game').style.display = 'block';
    loadLevel(level);
}

function loadLevel(n) {
    squares = [];
    enemies = [];
    score = 0;
    for(let i=0; i<n*5; i++){
        squares.push({x: i*60+50, y: 350, size: 40, color: 'blue'});
    }
    for(let i=0; i<n; i++){
        enemies.push({x: 100+i*150, y: 330, size: 40, speed: 2, image: new Image()});
        enemies[i].image.src = 'images/enemigo.png';
    }
    playMusic(`music/nivel${n}.mp3`);
    draw();
    gameLoop();
}

function draw() {
    ctx.clearRect(0,0,canvas.width,canvas.height);
    // Dibujar player
    ctx.drawImage(player.image, player.x, player.y, player.size, player.size);
    // Dibujar cuadrados
    squares.forEach(sq => {
        ctx.fillStyle = sq.color;
        ctx.fillRect(sq.x, sq.y, sq.size, sq.size);
    });
    // Dibujar enemigos
    enemies.forEach(en => {
        ctx.drawImage(en.image, en.x, en.y, en.size, en.size);
    });
    ctx.fillStyle = 'black';
    ctx.font = '20px Comic Sans MS';
    ctx.fillText('Puntos: ' + score, 10, 30);
}

function gameLoop() {
    moveEnemies();
    checkCollisions();
    draw();
    requestAnimationFrame(gameLoop);
}

function jump() { player.y -= 80; setTimeout(()=>{player.y+=80; draw();}, 300); }
function moveLeft() { player.x = Math.max(0, player.x-20); }
function moveRight() { player.x = Math.min(canvas.width-40, player.x+20); }

function moveEnemies() {
    enemies.forEach(e => {
        e.x += e.speed;
        if(e.x > canvas.width-40 || e.x < 0) e.speed *= -1;
    });
}

function checkCollisions() {
    enemies.forEach(e => {
        if(player.x < e.x + e.size && player.x + player.size > e.x &&
           player.y < e.y + e.size && player.y + player.size > e.y) {
            alert('¡Te atrapó un enemigo! Juego terminado.');
            backToMenu();
        }
    });
    squares.forEach((s, i) => {
        if(player.x < s.x + s.size && player.x + player.size > s.x &&
           player.y < s.y + s.size && player.y + player.size > s.y) {
            squares.splice(i,1);
            score += 10;
            if(squares.length === 0){
                level++;
                if(level > maxLevel){
                    alert('¡Ganaste el juego! Puntos totales: ' + score);
                    saveScore(score);
                    backToMenu();
                } else {
                    loadLevel(level);
                }
            }
        }
    });
}

function playMusic(file) {
    music.src = file;
    music.volume = volume;
    music.play();
}

function setVolume(v) {
    volume = v;
    music.volume = volume;
}

function showLeaderboard() {
    document.getElementById('menu').style.display = 'none';
    document.getElementById('leaderboard').style.display = 'block';
    fetchScores();
}

function showOptions() {
    document.getElementById('menu').style.display = 'none';
    document.getElementById('options').style.display = 'block';
}

function backToMenu() {
    document.getElementById('leaderboard').style.display = 'none';
    document.getElementById('game').style.display = 'none';
    document.getElementById('options').style.display = 'none';
    document.getElementById('menu').style.display = 'block';
}

function saveScore(puntos) {
    let nombre = prompt("Ingresa tu nombre para la tabla de clasificación");
    if(!nombre) nombre = "Anonimo";
    let scores = JSON.parse(localStorage.getItem('scores') || "[]");
    scores.push({nombre, puntos});
    scores.sort((a,b)=>b.puntos-a.puntos);
    localStorage.setItem('scores', JSON.stringify(scores));
}

function fetchScores() {
    let scores = JSON.parse(localStorage.getItem('scores') || "[]");
    let ul = document.getElementById('scores');
    ul.innerHTML = '';
    scores.slice(0,10).forEach(s => { ul.innerHTML += `<li>${s.nombre}: ${s.puntos}</li>`; });
}