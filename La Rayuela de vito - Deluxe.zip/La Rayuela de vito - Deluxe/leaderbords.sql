CREATE DATABASE RayuelaDeVito;

USE RayuelaDeVito;

CREATE TABLE jugadores (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(50),
    puntos INT,
    fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO jugadores (nombre, puntos) VALUES ('Vito', 100), ('Luiz', 80);